package jsp;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.mail.DefaultAuthenticator; 
import org.apache.commons.mail.Email;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.HtmlEmail;
/**
 * Servlet implementation class ForgetPass
 */
@WebServlet("/ForgetPass")
public class ForgetPass extends HttpServlet {
	private static final long serialVersionUID = 1L;
	JDBCMysql test = null;    
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ForgetPass() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		test = new JDBCMysql(); 
	}

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("Service method of Forgetpass Servlet");		
		
		
		String name=request.getParameter("name");
		
		String msg=" ";
		String pass = test.Retrieve_Pwd(name);
		
		String subject="���ըϥ� Gmail SMTP SSL�o�HPassword";
		String message = "<html><head><title>����</title></head><body>"+name+"�z���K�X�O "+pass+"</body></html>"; 

		Email email = new HtmlEmail(); 
		String authuser = "ycw517@gmail.com"; 
		String authpwd = "edencc755";
		email.setHostName("smtp.gmail.com");
		email.setSmtpPort(465); 
		email.setAuthenticator(new DefaultAuthenticator(authuser, authpwd));
		email.setDebug(true);
		email.setSSL(true);
		email.setSslSmtpPort("465");
		email.setCharset("UTF-8");
		email.setSubject(subject);
		try {
		    email.setFrom(authuser, "Preview Guide Center");
		    email.setMsg(message); 
		    email.addTo(name, "Dear Member");
		    email.send();
		    System.out.println("�l��o�e���\"); 
		} catch (EmailException e) {
			System.out.println("fail"); 
		    e.printStackTrace();
		}	

		msg = name + " PassWord has been sent to your email!!";
		PrintWriter out = response.getWriter();
		out.println("<font size='6' color=red>" + msg + "</font>");
	}

}
