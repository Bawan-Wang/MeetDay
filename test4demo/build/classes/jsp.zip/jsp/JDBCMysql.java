package jsp;

import java.sql.Connection; 
import java.sql.DriverManager; 
import java.sql.PreparedStatement; 
import java.sql.ResultSet; 
import java.sql.SQLException; 
import java.sql.Statement; 

import jsp.Const;

public class JDBCMysql {
	  private Connection con = null; 
	  private Statement stat = null;  
	  private ResultSet rs = null;  
	  private PreparedStatement pst = null; 
	  private String dropdbSQL = "DROP TABLE User "; 

	  private String updatedbipSQL = "UPDATE User SET ip_addr=? WHERE name=?";
	  private String updatedbfoneSQL = "UPDATE User SET phone_num=? WHERE name=?";
	  private String updatedbpwdSQL = "UPDATE User SET passwd=? WHERE name=?";
	  private String updatedblogSQL = "UPDATE User SET log_in=? WHERE name=?";
	  private String insertdbSQL_fri = "insert into friend_list(uid,fid) values(?,?)";
	  private String insertdbSQL = "insert into User(id,name) " + 
	      "select ifNULL(max(id),0)+1,? FROM User"; 
	  private String selectSQL_uid = "select id from User where name=?";
	  private String selectSQL_name = "select name from User where id=?";
	  private String selectSQL = "select * from User "; 
	  
	  public JDBCMysql() 
	  { 
	    try { 
	      Class.forName("com.mysql.jdbc.Driver"); 
	      con = DriverManager.getConnection(Const.sMySQLConnectionURL, Const.sUser, Const.sPassword); 
	      
	    } 
	    catch(ClassNotFoundException e) 
	    { 
	      System.out.println("DriverClassNotFound :"+e.toString()); 
	    }
	    catch(SQLException x) { 
	      System.out.println("Exception :"+x.toString()); 
	    } 
	    
	  } 
 
	  private int Get_UserId(String name)
	  {
	    try { 
	    	
	    	stat = con.createStatement(); 
		    rs = stat.executeQuery("select id from User where name='"+name+"'");       
		    rs.next();
		    //String tmp = rs.getString("id");

		    int tmp = Integer.valueOf(rs.getString("id"));
		    
		    return tmp;
		    } catch(SQLException e) { 
		      System.out.println("Get_UserId Exception :" + e.toString());
		      return 0;
		    }
	  }
	  
	  public String Get_UserName(int id)
	  {
		    try { 
		    	
		    	stat = con.createStatement(); 
			    rs = stat.executeQuery("select name from User where id="+id);       
			    rs.next();
			    String tmp = rs.getString("name");

			    return tmp;
			    } catch(SQLException e) { 
			      System.out.println("Get_UserId Exception :" + e.toString());
			      return null;
			    }		  
	  }
	  
	  public String Get_Friend(String name) 
	  { 
		  
		int uid =  Get_UserId(name);
		  
	    try 
	    { 
	      stat = con.createStatement(); 
	      rs = stat.executeQuery("select * from test.friend_list where uid="+uid); 
	      String list="";
	      while(rs.next()) 
	      { 
	    	list = list.concat(rs.getInt("fid") + "/");
	      } 	      
	      return list;
	    } 
	    catch(SQLException e) 
	    { 
	      System.out.println("Get_Friend Exception :" + e.toString()); 
	      return null;
	    } 
	    finally 
	    { 
	      Close(); 
	    } 
	  } 
	/*  
	  public String Get_Friend_Name(String uid) 
	  { 
		  
		
		  
	  } 
	  */
	  private boolean check_friend(int nameadd, int nameadded)
	  {
		  try 
		    { 
		      stat = con.createStatement(); 
		      String chkexist = "select exists(select 1 from test.friend_list where uid="+nameadd+" and fid="+nameadded+")";
		      rs = stat.executeQuery(chkexist); 
		      rs.next();
		      String tmp = rs.getString(1);
		      //System.out.println("xxx :"+tmp);
		      if (tmp.compareTo("1")==0){
		    	  //System.out.println("xxx3333 :");
		    	  return true;
		      } else {
		    	  //System.out.println("xxx666 :");
		    	  return false;
		      }		      
		    } catch(SQLException e) { 
		      System.out.println("checkExist Exception :" + e.toString()); 
		      return true;
		    } 		  	  
	  }
	  
	  public boolean Add_Friend( String nameadd, String nameadded) 
	  { 
		  
		if (Check_User_Exist(nameadded) == false){
			System.out.println("User Not Exists"); 
			return false;
		} 
			
		int tmpadd = Get_UserId(nameadd);
		int tmpadded = Get_UserId(nameadded);
		
		if(check_friend(tmpadd,tmpadded)==true){
			System.out.println("Friend Exists");
			return false;
		}
		
	    try {
	    
	      pst = con.prepareStatement(insertdbSQL_fri); 

	      pst.setInt(1, tmpadd); 
	      pst.setInt(2, tmpadded); 
	      pst.executeUpdate(); 
	      //Update_Pwd(name, passwd);
	      return true;
	    } catch(SQLException e) { 
	      System.out.println("InsertDB Exception :" + e.toString());
	      return false;
	    }
	    finally { 
	      Close(); 
	    } 
	  } 
	  
	  public boolean Add_User( String name, String passwd) 
	  { 
		  
		if (Check_User_Exist(name) == true){
			System.out.println("User Exists"); 
			return false;
		} 
		if (name.length()<2||name.length()>50){
			System.out.println("Length error"); 
			return false;			
		}
	    try { 
	      pst = con.prepareStatement(insertdbSQL); 
	      
	      pst.setString(1, name); 
	      pst.executeUpdate(); 
	      Update_Pwd(name, passwd);
	      return true;
	    } catch(SQLException e) { 
	      System.out.println("InsertDB Exception :" + e.toString());
	      return false;
	    }
	    finally { 
	      Close(); 
	    } 
	  } 

	  public boolean Do_Log_In( String name, String passwd) 
	  { 
		  
		if (Check_Passwd(name, passwd) == false){
			System.out.println("Wrong Password"); 
			return false;
		}
	    try { 
	      //pst = con.prepareStatement(insertdbSQL); 	      
	      //pst.setString(1, name); 
	      //pst.executeUpdate();
	      Update_LogIn_Status(name, true);
	      //Update_Pwd(name, passwd);
	      return true;
	    }catch(Exception e) { 
	      System.out.println("InsertDB Exception :" + e.toString());
	      return false;
	    } 
	    finally { 
	      Close(); 
	    } 
	  } 
	  
	  public boolean Do_Log_Out( String name) 
	  { 
		  
	    try { 
	      //pst = con.prepareStatement(insertdbSQL); 	      
	      //pst.setString(1, name); 
	      //pst.executeUpdate();
	      Update_LogIn_Status(name, false);
	      //Update_Pwd(name, passwd);
	      return true;
	    }catch(Exception e) { 
	      System.out.println("Do_Log_Out Exception :" + e.toString());
	      return false;
	    } 
	    finally { 
	      Close(); 
	    } 
	  } 
	  
	  public void Update_Phone( String name,String phone) 
	  { 
	    try 
	    { 
	      pst = con.prepareStatement(updatedbfoneSQL); 
	      
	      pst.setString(1, phone); 
	      pst.setString(2, name); 
	      pst.executeUpdate(); 
	    } 
	    catch(SQLException e) 
	    { 
	      System.out.println("InsertDB Exception :" + e.toString()); 
	    } 
	    finally 
	    { 
	      Close(); 
	    } 
	  } 
	  
	  public void Update_IP( String name,String ipaddr) 
	  { 
	    try 
	    { 
	      pst = con.prepareStatement(updatedbipSQL); 
	      
	      pst.setString(1, ipaddr); 
	      pst.setString(2, name); 
	      pst.executeUpdate(); 
	    } 
	    catch(SQLException e) 
	    { 
	      System.out.println("InsertDB Exception :" + e.toString()); 
	    } 
	    finally 
	    { 
	      Close(); 
	    } 
	  } 
	  
	  public void Update_Pwd( String name,String passwd) 
	  { 
	    try 
	    { 
	      pst = con.prepareStatement(updatedbpwdSQL); 
	      
	      pst.setString(1, passwd); 
	      pst.setString(2, name); 
	      pst.executeUpdate(); 
	    } 
	    catch(SQLException e) 
	    { 
	      System.out.println("InsertDB Exception :" + e.toString()); 
	    } 
	    finally 
	    { 
	      Close(); 
	    } 
	  } 

	  public String Retrieve_Pwd( String name) 
	  { 
		String getpass =  "select passwd from test.user where name='"+name+"'";
	    try 
	    { 
	      stat = con.createStatement(); 
	      rs = stat.executeQuery(getpass); 
	      rs.next();
	      String tmp = rs.getString(1);
	      return tmp;
	    } 
	    catch(SQLException e) 
	    { 
	      System.out.println("InsertDB Exception :" + e.toString()); 
	      return "";
	    } 
	    finally 
	    { 
	      Close(); 
	    } 
	  } 
	  
	  private void Update_LogIn_Status( String name,boolean login) 
	  { 
	    try 
	    { 
	      pst = con.prepareStatement(updatedblogSQL); 
	      
	      pst.setBoolean(1, login); 
	      pst.setString(2, name); 
	      pst.executeUpdate(); 
	    } 
	    catch(SQLException e) 
	    { 
	      System.out.println("Update_LogIn_Status Exception :" + e.toString()); 
	    } 
	    finally 
	    { 
	      Close(); 
	    } 
	  } 

	  public void dropTable() 
	  { 
	    try 
	    { 
	      stat = con.createStatement(); 
	      stat.executeUpdate(dropdbSQL); 
	    } 
	    catch(SQLException e) 
	    { 
	      System.out.println("DropDB Exception :" + e.toString()); 
	    } 
	    finally 
	    { 
	      Close(); 
	    } 
	  } 
 
	  public void SelectTable() 
	  { 
	    try 
	    { 
	      stat = con.createStatement(); 
	      rs = stat.executeQuery(selectSQL); 
	      System.out.println("ID\t\tName\t\tPASSWORD"); 
	      while(rs.next()) 
	      { 
	        System.out.println(rs.getInt("id")+"\t\t"+ 
	            rs.getString("name")+"\t\t"+rs.getString("passwd")); 
	      } 
	    } 
	    catch(SQLException e) 
	    { 
	      System.out.println("DropDB Exception :" + e.toString()); 
	    } 
	    finally 
	    { 
	      Close(); 
	    } 
	  } 
 
	  
	  private void Close() 
	  { 
	    try 
	    { 
	      if(rs!=null) 
	      { 
	        rs.close(); 
	        rs = null; 
	      } 
	      if(stat!=null) 
	      { 
	        stat.close(); 
	        stat = null; 
	      } 
	      if(pst!=null) 
	      { 
	        pst.close(); 
	        pst = null; 
	      } 
	    } 
	    catch(SQLException e) 
	    { 
	      System.out.println("Close Exception :" + e.toString()); 
	    } 
	  } 
	  
	  private boolean Check_User_Exist(String name){
		    try 
		    { 
		      stat = con.createStatement(); 
		      String chkexist = "select exists(select 1 from test.user where name='"+name+"')";
		      rs = stat.executeQuery(chkexist); 
		      rs.next();
		      String tmp = rs.getString(1);
		      //System.out.println("xxx :"+tmp);
		      if (tmp.compareTo("1")==0){
		    	  //System.out.println("xxx3333 :");
		    	  return true;
		      } else {
		    	  //System.out.println("xxx666 :");
		    	  return false;
		      }		      
		    } catch(SQLException e) { 
		      System.out.println("checkExist Exception :" + e.toString()); 
		      return true;
		    } 		  
	  }
	  
	  private boolean Check_Passwd(String name, String paswd) 
	  { 
	    try { 
	      if(!Check_User_Exist(name))
	    	  return false;
	      stat = con.createStatement(); 
	      rs = stat.executeQuery("select passwd from User where name='"+name+"'");       
	      rs.next();
	      String tmp = rs.getString("passwd");
	      //System.out.println("PASSWORD :"+tmp);
	      //System.out.println("PASSWORD :"+paswd);
	      int flag = paswd.compareTo(tmp);
	      if(flag == 0)
	    	  return true;
	      else
	    	  return false;
	    } 
	    catch(SQLException e) { 
	      System.out.println("CheckPasswd Exception :" + e.toString()); 
	      return false;
	    } 
	    finally 
	    { 
	      Close(); 
	    } 
	  } 
	  
	  public static void main(String[] args) 
	  { 
	    //���ݬݬO�_���` 
		JDBCMysql test = new JDBCMysql(); 
	    //test.dropTable(); 
	    //test.createTable(); 
	    //test.insertTable("yku", "12356");
		//test.Update_Phone("ycw517@gmail.com", "0912721590");
		//;
		//System.out.println(test.Get_UserId("yuki"));
		//test.Add_Friend("ycw517", "ppp");
		String xx=test.Get_Friend("ycw517");
		System.out.println(xx);
		String flist="";
		while(xx.contains("/")){
			int tmp = xx.indexOf("/");
			String str=xx.substring(0, tmp);
			flist=flist.concat(test.Get_UserName(Integer.valueOf(str))+"/");
			xx=xx.substring(tmp+1);
		}
		System.out.println(flist);
		
	    //test.SelectTable(); 
	    //boolean tt = test.checkExist("yku2");
	    //if(tt==true)
	    	//System.out.println("CheckPasswd TRue " ); 
	    //else
	    	//System.out.println("CheckPasswd False " ); 
	    //test.checkExist("yku");
	  
	  } 
}
