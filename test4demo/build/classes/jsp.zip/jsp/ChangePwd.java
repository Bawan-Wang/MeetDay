package jsp;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ChangePwd
 */
@WebServlet("/ChangePwd")
public class ChangePwd extends HttpServlet {
	private static final long serialVersionUID = 1L;
	JDBCMysql test = null;      
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ChangePwd() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		test = new JDBCMysql(); 
	}

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("Service ChangePwd of Servlet");		
		
		
		String name=request.getParameter("name");
		String pass=request.getParameter("pass");
		//String ip = request.getRemoteAddr();
		
		String msg ="";
		//String fidlst =" ";
		
		test.Update_Pwd(name, pass);
		if(test.Do_Log_Out(name) == true){
			msg="Change Successful!!";
			System.out.println("Logout Successful! "+name);
			//response.sendRedirect( "index.html");  
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();
			//out.println("<font size='6' color=red>" + msg + "</font>");
			out.println(msg);
			response.setHeader("REFRESH","2;URL=index.html");
		}else{
			msg="Change Fail!!";
			System.out.println("Logout Fail!");
		}
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		//out.println("<font size='6' color=red>" + msg + "</font>");
		//out.println(msg);
		
		//if(test.Do_Log_In(name, pass) == true){
		//response.setHeader("REFRESH","2;URL=index.html");
			 //response.sendRedirect( "Welcome.jsp?name="+name);   
		//}
	}

}
