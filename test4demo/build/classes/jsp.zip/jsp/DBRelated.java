package jsp;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class DBRelated
 */
@WebServlet("/DBRelated")
public class DBRelated extends HttpServlet {
	private static final long serialVersionUID = 1L;
	DBFunction dbf = null;    
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DBRelated() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		dbf = new DBFunction(); 
	}

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("Service of Servlet");	
		Const.Command cmd = null;
		
		HttpSession session = request.getSession(false);
		try{
			cmd = (Const.Command)session.getAttribute("cmd");
		}catch(Exception e){	
			cmd = Const.Command.valueOf(request.getParameter("cmd"));
		}
		
		
		System.out.println("Cmd:"+cmd);
		
		switch(cmd){
			case Cmd_Login:
				String name_login=request.getParameter("name");
				String pass_login=request.getParameter("pass");
				String ip = request.getRemoteAddr();			
				System.out.println("name:"+name_login+"  pass:"+pass_login+"  ip:"+ip);
				dbf.DB_Login(name_login, pass_login, ip, response);
				break;
			case Cmd_Logout:				
				String name_logout=(String)session.getAttribute("name");			
				dbf.DB_Logout(name_logout, response);
				break;
			case Cmd_Register:
				String name_reg=request.getParameter("name");
				String pass_reg=request.getParameter("pass");
				String phone_reg=request.getParameter("phone");
				dbf.DB_Register(name_reg, pass_reg, phone_reg, response);
				break;
			case Cmd_ForgetPwd:
				String name_fgtpwd=request.getParameter("name");
				dbf.DB_ForgetPwd(name_fgtpwd, response);
				break;
			case Cmd_AddFriend:
				String name_frndadd=(String)session.getAttribute("name");//request.getParameter("name");
				String name_frndadded=request.getParameter("nameadded");
				dbf.DB_Addfreind(name_frndadd, name_frndadded, response);
				break;
			case Cmd_ChangePwd:
				String name_chpwd=request.getParameter("name");
				String pass_chpwd=request.getParameter("pass");
				dbf.DB_ChangePwd(name_chpwd, pass_chpwd, response);
				break;
			case Cmd_GetUsrData:
				break;
		}
		//String nameadd=(String)session.getAttribute("name");//request.getParameter("name");
		//String nameadd=request.getParameter("nameadd");
		//String nameadded=request.getParameter("nameadded");
	}

}
