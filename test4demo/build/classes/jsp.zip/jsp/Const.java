package jsp;

public class Const {
	public static String sMySQLIP = "127.0.0.1";
	public static String sMySQLPort = "3306";
	public static String sMySQLPath = sMySQLIP + ":" + sMySQLPort;
	public static String sMySQLDatabase = "test";
	public static String sUser = "root";
	public static String sPassword = "1234";
	public static String sMySQLConnectionURL = "jdbc:mysql://" + sMySQLPath + "/" + sMySQLDatabase + "?useUnicode=true&characterEncoding=utf-8";
	//+ "user=" + sUser + "&password=" + sPassword;  
	//"jdbc:mysql://127.0.0.1:3306/ncku_emba?" + "user=root&password=79993812"
	public enum Command {
		Cmd_Login, Cmd_Logout, Cmd_Register, Cmd_ForgetPwd, Cmd_AddFriend, Cmd_ChangePwd, Cmd_GetUsrData
	}

}
