package jsp;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.mail.DefaultAuthenticator; 
import org.apache.commons.mail.Email;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.HtmlEmail;
/**
 * Servlet implementation class RegisterServlet
 */
@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	JDBCMysql test = null;   
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		test = new JDBCMysql(); 
	}

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("Service method of Reg Servlet");		
		
		
		String name=request.getParameter("name");
		String pass=request.getParameter("pass");
		String phone=request.getParameter("phone");
		
		String msg=" ";
		
		if(test.Add_User(name, pass) == true){
			msg="Add User "+name+ " Successful!!";
			if(phone != null){
				test.Update_Phone(name, phone);
			}
			
			String subject="���ըϥ� Gmail SMTP SSL�o�H";
			String message = "<html><head><title>����</title></head><body>�o�O�@�ʴ��իH�A����Цۦ�R��</body></html>"; 

			Email email = new HtmlEmail(); 
			String authuser = "ycw517@gmail.com"; 
			String authpwd = "edencc755";
			email.setHostName("smtp.gmail.com");
			email.setSmtpPort(465); 
			email.setAuthenticator(new DefaultAuthenticator(authuser, authpwd));
			email.setDebug(true);
			email.setSSL(true);
			email.setSslSmtpPort("465");
			email.setCharset("UTF-8");
			email.setSubject(subject);
			try {
			    email.setFrom(authuser, "�����ȪA����");
			    email.setMsg(message); 
			    email.addTo(name, "�˷R���|��");
			    email.send();
			    System.out.println("�l��o�e���\"); 
			} catch (EmailException e) {
				System.out.println("fail"); 
			    e.printStackTrace();
			}	
		}else{
			msg="Add Fail!!";
		}
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<font size='6' color=red>" + msg + "</font>");
		response.setHeader("REFRESH","2;URL=index.html");
	}

}
