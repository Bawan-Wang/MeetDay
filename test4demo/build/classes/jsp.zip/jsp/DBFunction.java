package jsp;

import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.mail.DefaultAuthenticator;
import org.apache.commons.mail.Email;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.HtmlEmail;

public class DBFunction {
	JDBCMysql test = null;
	 public DBFunction() {
		 test = new JDBCMysql(); 
	 }
	 
	 public void DB_Login(String name, String pass, String ip, HttpServletResponse response){
		String msg="";
		String fidlst="";
		if(test.Do_Log_In(name, pass) == true){
			test.Update_IP(name, ip);
			fidlst=test.Get_Friend(name);
			msg=fidlst;	
			response.setContentType("text/html");
			try{
				PrintWriter out = response.getWriter();
				out.println(msg);
				response.setHeader("REFRESH","2;URL=Welcome.jsp?name="+name+"&fidlst="+fidlst);
			}catch(Exception e){
				
			}
			
		}else{
			//msg="Login Fail!!";
		}
	 }
	 
	 public void DB_Logout(String name,  HttpServletResponse response){
		
		if(test.Do_Log_Out(name) == true){
			String msg="";
			response.setContentType("text/html");
			try{
				msg="Logout Successful";
				PrintWriter out = response.getWriter();
				out.println(msg);
				response.setHeader("REFRESH","2;URL=index.jsp");
			}catch(Exception e){
				
			}
		}else{

		}
	 }

	 public void DB_Register(String name,  String pass, String fone, HttpServletResponse response){
		 
		 String msg="";
		 if(test.Add_User(name, pass) == true){		
			msg="Add User "+name+ " Successful!!";
			if(fone != null){
				test.Update_Phone(name, fone);
			}
			
			MailRelated mrl = new MailRelated();
			
			mrl.Mail_Reg(name, pass);
			
			/*String subject="Welcome to PreviewGuide";
			String message = "<html><head><title>Register</title></head><body>Thank you for your registration <br>"
					+ "Name:"+name+ "<br> Pass:"+pass+"</body></html>"; 

			Email email = new HtmlEmail(); 
			String authuser = "ycw517@gmail.com"; 
			String authpwd = "edencc755";
			email.setHostName("smtp.gmail.com");
			email.setSmtpPort(465); 
			email.setAuthenticator(new DefaultAuthenticator(authuser, authpwd));
			email.setDebug(true);
			email.setSSL(true);
			email.setSslSmtpPort("465");
			email.setCharset("UTF-8");
			email.setSubject(subject);
			try {
			    email.setFrom(authuser, "PreviewGuide Center");
			    email.setMsg(message); 
			    email.addTo(name, "Dear Member");
			    email.send();
			    System.out.println("Email Sent"); 
			} catch (EmailException e) {
				System.out.println("fail"); 
			    e.printStackTrace();
			}	
			*/
		}else{
			msg="Add Fail!!";
		}
		
		 try{
			 response.setContentType("text/html");
			 PrintWriter out = response.getWriter();
			 out.println("<font size='6' color=red>" + msg + "</font>");
			 response.setHeader("REFRESH","2;URL=index.jsp");
		 }catch(Exception e){
			 
		 }

		 
		 
		 }
	 
	 public void DB_ForgetPwd(String name,  HttpServletResponse response){
		 
		String msg="";
		String pass = test.Retrieve_Pwd(name);
			
		MailRelated mrl = new MailRelated();
		
		mrl.Mail_ForgetPwd(name, pass);
		
		/*String subject="PreviewGuide Send Password";
		String message = "<html><head><title>SendPass</title></head><body>Hi, "+name+" Your Password: "+pass+"</body></html>"; 

		Email email = new HtmlEmail(); 
		String authuser = "ycw517@gmail.com"; 
		String authpwd = "edencc755";
		email.setHostName("smtp.gmail.com");
		email.setSmtpPort(465); 
		email.setAuthenticator(new DefaultAuthenticator(authuser, authpwd));
		email.setDebug(true);
		email.setSSL(true);
		email.setSslSmtpPort("465");
		email.setCharset("UTF-8");
		email.setSubject(subject);
		try {
		    email.setFrom(authuser, "Preview Guide Center");
		    email.setMsg(message); 
		    email.addTo(name, "Dear Member");
		    email.send();
		    System.out.println("�l��o�e���\"); 
		} catch (EmailException e) {
			System.out.println("fail"); 
		    e.printStackTrace();
		}	

		*/
	
		 try{
			response.setContentType("text/html");
			msg = name + " PassWord has been sent to your email!!";
			PrintWriter out = response.getWriter();
			out.println("<font size='6' color=red>" + msg + "</font>");
			response.setHeader("REFRESH","2;URL=index.jsp");
		 }catch(Exception e){
			 
		 }

		 
		 
	}
	 
	 public void DB_Addfreind(String nameadd,  String nameadded, HttpServletResponse response){
		
		 
		String msg=" ";
			
		if(test.Add_Friend(nameadd, nameadded)==true){			
			msg="Add Freind "+nameadded+"  Successful!!";
		}else{
			msg="AddFriend Fail!!";
		}
			
		try{
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();
			out.println("<font size='6' color=red>" + msg + "</font>");
			response.setHeader("REFRESH","2;URL=Welcome.jsp?name="+nameadd);
		}catch(Exception e){
			
		}

		
	 }
	 public void DB_ChangePwd(String name,  String pass, HttpServletResponse response){
			
		 
			String msg=" ";
			test.Update_Pwd(name, pass);
			if(test.Do_Log_Out(name) == true){
				msg="Change Successful!!";
				System.out.println("Logout Successful! "+name);
				try{
					response.setContentType("text/html");
					PrintWriter out = response.getWriter();
					out.println(msg);
					response.setHeader("REFRESH","2;URL=index.jsp");
				}catch(Exception e){
					
				}
			}else{
				msg="Change Fail!!";
				System.out.println("Logout Fail!");
			}
						
		 }
}
