package jsp;

import org.apache.commons.mail.DefaultAuthenticator;
import org.apache.commons.mail.Email;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.HtmlEmail;

public class MailRelated {
	
	private String authuser = "ycw517@gmail.com"; 
	private String authpwd = "edencc755";
	private String hostname = "smtp.gmail.com";
	private int smtpport = 465;
	private String Charset = "UTF-8";
	
	public MailRelated() {
		 //test = new JDBCMysql(); 
	 }
	
	public void Mail_Reg(String name, String pass){
		String subject="Welcome to PreviewGuide";
		String message = "<html><head><title>Register</title></head><body>Thank you for your registration <br>"
				+ "Name:"+name+ "<br> Pass:"+pass+"</body></html>"; 

		Email email = new HtmlEmail(); 
		//String authuser = "ycw517@gmail.com"; 
		//String authpwd = "edencc755";
		email.setHostName(hostname);
		email.setSmtpPort(smtpport); 
		email.setAuthenticator(new DefaultAuthenticator(authuser, authpwd));
		email.setDebug(true);
		email.setSSL(true);
		email.setSslSmtpPort(Integer.toString(smtpport));
		email.setCharset(Charset);
		email.setSubject(subject);
		try {
		    email.setFrom(authuser, "PreviewGuide Center");
		    email.setMsg(message); 
		    email.addTo(name, "Dear Member");
		    email.send();
		    System.out.println("Email Sent"); 
		} catch (EmailException e) {
			System.out.println("fail"); 
		    e.printStackTrace();
		}	
	}
	
	public void Mail_ForgetPwd(String name, String pass){
		String subject="PreviewGuide Send Password";
		String message = "<html><head><title>SendPass</title></head><body>Hi, "+name+" Your Password: "+pass+"</body></html>"; 

		Email email = new HtmlEmail(); 
		//String authuser = "ycw517@gmail.com"; 
		//String authpwd = "edencc755";
		email.setHostName(hostname);
		email.setSmtpPort(smtpport); 
		email.setAuthenticator(new DefaultAuthenticator(authuser, authpwd));
		email.setDebug(true);
		email.setSSL(true);
		email.setSslSmtpPort(Integer.toString(smtpport));
		email.setCharset(Charset);
		email.setSubject(subject);
		try {
		    email.setFrom(authuser, "Preview Guide Center");
		    email.setMsg(message); 
		    email.addTo(name, "Dear Member");
		    email.send();
		    System.out.println("Email Sent"); 
		} catch (EmailException e) {
			System.out.println("fail"); 
		    e.printStackTrace();
		}	

	}
}
